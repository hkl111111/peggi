<?php
  $con=mysqli_connect("192.168.0.253","root","123456","blog");
  if (mysqli_connect_errno())
  {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $sql="
  select * from blogcontent where id='$_POST[id]'
  ";
  $data=array();
    class User{
    public $id;
    public $time;
    public $title;
    public $content;
    }
    $result = mysqli_query($con,$sql);
    while($row = mysqli_fetch_array($result))
    {
       $user=new User();
       $user->id=$row[id];
       $user->time=$row[time];
       $user->title=$row[title];
       $user->content=$row[content];
       $data[]=$user;
    }
    echo json_encode($data);
    mysqli_close($con);
?>