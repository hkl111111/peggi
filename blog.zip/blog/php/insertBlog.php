<?php
  $con=mysqli_connect("192.168.0.253","root","123456","blog");
  if (mysqli_connect_errno())
  {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $sql="insert into blogcontent(id,time,title,content)
  values
  ($_POST[id],'$_POST[time]','$_POST[title]','$_POST[content]')";
  if(!mysqli_query($con,$sql))
  {
      echo "error";
  }
  else{
  echo '{"msg":"success","status":"2"}';
  }

  mysqli_close($con);
?>